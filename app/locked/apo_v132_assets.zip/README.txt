APO locked-icon gradient startup v132 — source/binary handoff (not an APK)

Selected, locked app icon: original forest_green_mountain_ribbon_icon.png, byte-identical copy under app/src/main/assets/apo_official_master.png.
Startup: transparent mountain-only derivative, native gradient #0B4B39→#021918, separate native APO wordmark.
Animation staged on feature/apo-startup-screen-v1-design: mountain 380ms fade, title 320ms fade starting +90ms, identity 190ms fade then Android Home fade. Honors reduce motion and reference initialization.

Install these three exact PNG paths into branch feature/apo-startup-screen-v1-design, or extract this ZIP at the repository root. GitHub draft PR #74 contains Android code and tests. No other source edits are needed for the documented design.
The supplied apply_and_build.sh can copy/verify these assets from the extracted handoff directory, then build using Android SDK 35, Gradle 8.11.1 and original signing key. It refuses the wrong version, missing original signer, or wrong hash.

This ZIP is an artifact overlay, NOT a signed APK. No Android build has been run here. Verify full scientific tests, APK signature, field history and on-device upgrade before field deployment.
