#!/usr/bin/env bash
set -euo pipefail
# Run in a checkout of feature/apo-startup-screen-v1-design.
ROOT="${1:-.}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [ ! -f app/build.gradle ] || [ ! -f app/src/main/java/org/phwildlife/survey/LikasLaunchActivity.java ]; then
  echo 'ERROR: Run against the APO Android repository checkout.' >&2; exit 2
fi
if ! grep -q 'versionCode 132' app/build.gradle; then
  echo 'ERROR: wrong branch/version. Expected APO v132.' >&2; exit 2
fi
cp "$HERE/app/src/main/assets/apo_official_master.png" app/src/main/assets/apo_official_master.png
cp "$HERE/app/src/main/res/drawable-nodpi/apo_splash_mark.png" app/src/main/res/drawable-nodpi/apo_splash_mark.png
cp "$HERE/app/src/main/res/drawable-nodpi/apo_launcher_foreground.png" app/src/main/res/drawable-nodpi/apo_launcher_foreground.png
printf '%s\n' \
 '6fe44e5117e0bde953b529735bc7d61a633f39201097a2fd68cd560e914ba0e7  app/src/main/assets/apo_official_master.png' \
 'a194803302b7e6c884068ff4e3e3926ba4a4e4110986e599e09a2e6dd7fd22bc  app/src/main/res/drawable-nodpi/apo_splash_mark.png' \
 '2a60cc5cda8dba006c1c713f15d565c4599ad5ec1bcaebadc7690cb66445af00  app/src/main/res/drawable-nodpi/apo_launcher_foreground.png' | sha256sum -c -
if [ ! -s .signing/wildlife-beta08.keystore ]; then
  echo 'ERROR: original LIKAS signing keystore missing; cannot provide safe in-place update.' >&2; exit 3
fi
keytool -exportcert -keystore .signing/wildlife-beta08.keystore -storepass android -alias androiddebugkey -file /tmp/apo-original-cert.der
printf 'f7c471ad310aeeffd2b2a7cf7c371c6efdce258560a818b52be5e1f2a7509937  /tmp/apo-original-cert.der\n' | sha256sum -c -
if ! command -v gradle >/dev/null; then
  echo 'ERROR: Gradle 8.11.1 and Android SDK 35 required.' >&2; exit 4
fi
python3 -m unittest scripts/test_apo_startup_locked_icon.py
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
APK=app/build/outputs/apk/debug/app-debug.apk
test -s "$APK"
: "${ANDROID_HOME:?Set ANDROID_HOME for Android SDK 35}"
"$ANDROID_HOME/build-tools/35.0.0/aapt" dump badging "$APK" | grep -F "name='org.phwildlife.survey.beta08' versionCode='132'"
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose --print-certs "$APK" | grep -iF 'f7c471ad310aeeffd2b2a7cf7c371c6efdce258560a818b52be5e1f2a7509937'
printf 'Verified candidate: %s\n' "$APK"
sha256sum "$APK"
# Note: this does not certify field records or physical handset upgrades.
